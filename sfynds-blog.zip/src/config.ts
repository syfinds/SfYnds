// Edit this file to configure the whole site.
export const SITE = {
  name: 'SfYnds',
  tagline: 'Discover Better. Choose Smarter.',
  description: 'Discover useful products, practical buying guides, and smarter everyday finds.',
  url: 'https://sfynds.example.com', // TODO: replace with your real domain
  author: 'SfYnds Team',
  contactEmail: '', // TODO: add your real email, e.g. 'hello@yourdomain.com'
  postsPerPage: 6,
};
// TODO: replace each URL with your real profile link.
export const SOCIALS = [
  { name: 'Instagram', url: 'https://www.instagram.com/your-handle' },
  { name: 'Pinterest', url: 'https://www.pinterest.com/your-handle' },
  { name: 'YouTube', url: 'https://www.youtube.com/@your-handle' },
  { name: 'Facebook', url: 'https://www.facebook.com/your-page' },
  { name: 'LinkedIn', url: 'https://www.linkedin.com/company/your-page' },
  { name: 'X', url: 'https://x.com/your-handle' },
];
export const NAV = [
  { label: 'Home', href: '/' }, { label: 'Blog', href: '/blog' },
  { label: 'About', href: '/about' }, { label: 'Contact', href: '/contact' },
];
