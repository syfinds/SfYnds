# SfYnds blog

Static Astro site: Markdown posts, no database, free hosting.

## Run locally
```
npm install
npm run dev      # http://localhost:4321
npm run build    # outputs dist/
```

## First setup (do this once)
Edit `src/config.ts`: site `url` (your real domain), `contactEmail`, and the six social profile URLs.
Also review `/privacy-policy` and `/affiliate-disclosure` (look for highlighted "verify" notes).

## Publish a new post
1. Add a file `src/content/blog/your-post-slug.md` (the filename becomes the URL: `/blog/your-post-slug`).
2. Copy this front matter and fill it in:
```
---
title: "Post title"
description: "Meta description, about 150 characters"
pubDate: 2026-11-01
category: "Buying Guides"
tags: ["tag1", "tag2"]
image: "/images/your-image.jpg"   # file in public/images/
imageAlt: "Describe the image"
seoTitle: "Optional shorter title for Google"
featured: false
hasAffiliateLinks: true           # shows the disclosure box
draft: false                      # true hides it
---
```
3. Write in Markdown. For an affiliate link, add `#affiliate` to the end of **your approved link**:
   `[Buy here](https://your-approved-link#affiliate)`. The site removes the `#affiliate`, opens it in a new tab and adds `rel="sponsored nofollow noopener"`.
4. Delete the sample posts (`sample: true`) before launch.
5. Commit and push; the host rebuilds automatically.

## Deploy
**Cloudflare Pages:** connect your Git repo, build command `npm run build`, output directory `dist`.
**GitHub Pages:** push to GitHub, enable Pages with GitHub Actions (Astro "withastro/action"). For a project site (`user.github.io/repo`) also set `base: '/repo'` in `astro.config.mjs`.
