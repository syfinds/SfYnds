import { getCollection } from 'astro:content';
export const getPosts = async () =>
  (await getCollection('blog', (p) => !p.data.draft)).sort((a, b) => +b.data.pubDate - +a.data.pubDate);
export const fmt = (d: Date) => d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
export const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
