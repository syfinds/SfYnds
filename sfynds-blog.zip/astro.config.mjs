import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';
import { SITE } from './src/config.ts';

// Links ending in #affiliate become rel="sponsored nofollow noopener" and open in a new tab.
function rehypeAffiliate() {
  const walk = (n) => {
    if (n.type === 'element' && n.tagName === 'a' && n.properties?.href) {
      const h = String(n.properties.href);
      if (h.endsWith('#affiliate')) {
        n.properties.href = h.replace('#affiliate', '');
        n.properties.rel = ['sponsored', 'nofollow', 'noopener'];
        n.properties.target = '_blank';
        n.properties.className = ['affiliate'];
      } else if (/^https?:\/\//.test(h) && !h.startsWith(SITE.url)) {
        n.properties.rel = ['noopener'];
        n.properties.target = '_blank';
      }
    }
    (n.children || []).forEach(walk);
  };
  return (tree) => walk(tree);
}

export default defineConfig({
  site: SITE.url,
  integrations: [sitemap()],
  markdown: { rehypePlugins: [rehypeAffiliate] },
});
